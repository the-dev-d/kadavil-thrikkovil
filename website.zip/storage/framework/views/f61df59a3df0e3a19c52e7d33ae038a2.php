<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="flex items-center p-6 my-3 bg-white rounded-md shadow-sm">
                <span class="material-symbols-outlined">
                    error
                </span> 
                <p class="ml-2">വഴിപാടുകൾ ബുക്ക്  ചെയ്തതിനു ശേഷമുള്ള വഴിപാട് സമയങ്ങളിലായി ചെയ്യപ്പെടും. പൂർത്തിയായ വഴിപാട് ക്ഷേത്രത്തിൽനിന്ന് നേരിട്ട് വാങ്ങാവുന്നതാണ് </p>
            </div>
            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <h3 class="w-full text-lg font-semibold border-b-2 border-slate-400">Booked Today</h3>
                       <div class="grid gap-2 py-3">
                        <?php if($bookings): ?>

                            <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="grid grid-cols-2 gap-4 p-3 border-2 rounded-md shadow-sm list-icon-item border-slate-300">
                                    <div class="grid place-items-center">
                                        <?php if($booking->completed): ?>
                                            <span class="text-green-400 material-symbols-outlined">
                                                done
                                            </span>
                                        <?php else: ?>
                                            <span class="material-symbols-outlined">
                                                schedule
                                            </span>
                                        <?php endif; ?>
                                        
                                    </div>
                                    <div class="flex items-center justify-between">
                                        <div class="grid gap-2">
                                            <div class="text-xl capitalize ">
                                                <?php echo e($booking->offering_name); ?> 
                                            </div>
                                            <div class="text-xl">
                                                <?php echo e($booking->booked_name); ?> - <?php echo e($booking->star_name); ?>

                                            </div>
                                            <span><?php echo e($booking->created_at); ?></span>

                                        </div>
                                        <span class="text-base font-semibold">Rs.<?php echo e($booking->price); ?></span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                       </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/devd/WorkProjects/Php/kadavil_thrikkovil_webapp/resources/views/dashboard.blade.php ENDPATH**/ ?>