<?php echo e($slot); ?>

<?php /**PATH /home/devd/WorkProjects/Php/kadavil_thrikkovil_webapp/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>