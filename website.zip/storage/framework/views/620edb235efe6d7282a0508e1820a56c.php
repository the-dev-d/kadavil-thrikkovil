<div>
    <form action="" method="POST">
        <input type="text" name="email" id="email">
        <button>Get Login</button>
    </form>
</div><?php /**PATH /home/devd/WorkProjects/Php/kadavil_thrikkovil_webapp/resources/views/console.blade.php ENDPATH**/ ?>