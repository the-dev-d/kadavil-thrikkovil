<?php if (isset($component)) { $__componentOriginal3cc710b2fb1cfcc6cba554e9525ade40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3cc710b2fb1cfcc6cba554e9525ade40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.base-app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="mt-20 antialiased">
        <div class="container p-3 mx-auto bg-white">
            <div class="flex items-center justify-center gap-6 p-6 my-3 bg-white border-2 rounded-md shadow-md ">
                <span class="material-symbols-outlined">
                    error
                </span> 
                <div>
                    <p class="ml-2">വഴിപാടുകൾ ബുക്ക്  ചെയ്തതിനു ശേഷമുള്ള വഴിപാട് സമയങ്ങളിലായി ചെയ്യപ്പെടും. പൂർത്തിയായ വഴിപാട് ക്ഷേത്രത്തിൽനിന്ന് നേരിട്ട് വാങ്ങാവുന്നതാണ്. </p>
                    <p class="ml-2">                        
                        ബുക്കിങ്ങിന്റെ 2-3% വരെ പേയ്‌മെന്റ് പ്രൊവൈഡർ ചാർജ് അധികമായി ഈടാക്കാവുന്നതാണ്.
                    </p>
                </div>
            </div>
        </div>
        <div class="container grid gap-3 p-3 mx-auto bg-white md:grid-cols-2">
            <?php $__currentLoopData = $offerings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offering): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="grid items-center w-full gap-6 p-6 bg-white border-2 rounded-sm border-slate-200 grid-cols-nav">
                    <div class="w-full">
                        <div class="text-xl capitalize text-slate-800">
                            <?php echo e($offering->name); ?>

                        </div>
                        <h5 class="mt-2 text-xl font-semibold">Rs.<?php echo e($offering->price); ?></h5>
                    </div>
                    <a class="xl:w-full justify-self-end" href=<?php echo e(route('offerings')."/".$offering->id); ?>>
                        <button type="button" class="text-white xl:w-full bg-amber-500 hover:bg-amber-800 focus:ring-4 focus:ring-amber-300 font-medium rounded-lg text-sm px-5 py-2.5  focus:outline-none">Book</button>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3cc710b2fb1cfcc6cba554e9525ade40)): ?>
<?php $attributes = $__attributesOriginal3cc710b2fb1cfcc6cba554e9525ade40; ?>
<?php unset($__attributesOriginal3cc710b2fb1cfcc6cba554e9525ade40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3cc710b2fb1cfcc6cba554e9525ade40)): ?>
<?php $component = $__componentOriginal3cc710b2fb1cfcc6cba554e9525ade40; ?>
<?php unset($__componentOriginal3cc710b2fb1cfcc6cba554e9525ade40); ?>
<?php endif; ?>
    

<?php /**PATH /home/devd/WorkProjects/Php/kadavil_thrikkovil_webapp/resources/views/offerings.blade.php ENDPATH**/ ?>