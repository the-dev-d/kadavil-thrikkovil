<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/devd/WorkProjects/Php/kadavil_thrikkovil_webapp/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>