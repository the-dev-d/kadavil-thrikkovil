<?php if (isset($component)) { $__componentOriginal3cc710b2fb1cfcc6cba554e9525ade40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3cc710b2fb1cfcc6cba554e9525ade40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.base-app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container grid h-screen p-3 mx-auto place-items-center">
        <div class="grid w-full gap-10 p-10 m-3 mt-20 overflow-hidden border-2 rounded-md shadow-md lg:w-1/2 border-slate-200">
            <div class="grid gap-3">
                <div class="text-xl capitalize"><?php echo e($name); ?></div>
                <div>
                    <div class="text-2xl font-semibold">Rs. <?php echo e($price); ?></div>
                    <h5 class="mt-2 text-slate-400">+3% payment gateway charge</h5>
                </div>
            </div>
            <form action=<?php echo e(route('booking')); ?> class="grid gap-6 my-3" method="POST">
                <?php echo e(csrf_field()); ?>

                <input class="hidden" type="text" name="offering" value=<?php echo e($id); ?>>
                <div class="">
                    <label for="name" class="block mb-2 text-sm font-medium text-gray-900">Name</label>
                    <input pattern="[A-z]+" title="Only letters are allowed" name="name" type="text" id="name" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="Enter name" required>
                </div>
                <select name="star" id="star" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                    <?php $__currentLoopData = $stars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $star): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($star->id); ?>><?php echo e($star->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5  mb-2 focus:outline-none">
                    Rs.<?php echo e(round($price*100/97,2)); ?>

                </button>
            </form>
        </div>
        
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3cc710b2fb1cfcc6cba554e9525ade40)): ?>
<?php $attributes = $__attributesOriginal3cc710b2fb1cfcc6cba554e9525ade40; ?>
<?php unset($__attributesOriginal3cc710b2fb1cfcc6cba554e9525ade40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3cc710b2fb1cfcc6cba554e9525ade40)): ?>
<?php $component = $__componentOriginal3cc710b2fb1cfcc6cba554e9525ade40; ?>
<?php unset($__componentOriginal3cc710b2fb1cfcc6cba554e9525ade40); ?>
<?php endif; ?><?php /**PATH /home/devd/WorkProjects/Php/kadavil_thrikkovil_webapp/resources/views/offerings_form.blade.php ENDPATH**/ ?>