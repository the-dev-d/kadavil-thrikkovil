<?php if (isset($component)) { $__componentOriginalc2f63710d6c705b13c4c0ed4036688f0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2f63710d6c705b13c4c0ed4036688f0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-menu','data' => ['user' => $user]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user)]); ?> Hello  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2f63710d6c705b13c4c0ed4036688f0)): ?>
<?php $attributes = $__attributesOriginalc2f63710d6c705b13c4c0ed4036688f0; ?>
<?php unset($__attributesOriginalc2f63710d6c705b13c4c0ed4036688f0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2f63710d6c705b13c4c0ed4036688f0)): ?>
<?php $component = $__componentOriginalc2f63710d6c705b13c4c0ed4036688f0; ?>
<?php unset($__componentOriginalc2f63710d6c705b13c4c0ed4036688f0); ?>
<?php endif; ?><?php /**PATH /home/devd/WorkProjects/Php/kadavil_thrikkovil_webapp/resources/views/admin/console.blade.php ENDPATH**/ ?>