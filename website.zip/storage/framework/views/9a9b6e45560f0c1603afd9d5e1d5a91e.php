<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
    <title>Kadavil Thrikkovil</title>
    
    <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body>
    <?php echo e($slot); ?>

</body>
</html><?php /**PATH /home/devd/WorkProjects/Php/kadavil_thrikkovil_webapp/resources/views/components/base-app.blade.php ENDPATH**/ ?>