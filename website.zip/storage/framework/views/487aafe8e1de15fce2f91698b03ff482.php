<?php if (isset($component)) { $__componentOriginal3cc710b2fb1cfcc6cba554e9525ade40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3cc710b2fb1cfcc6cba554e9525ade40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.base-app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> 

    <div class="container grid w-screen h-screen mx-auto place-items-center">

        <div class="flex items-center justify-center gap-3 p-16 text-2xl border-2 rounded-md shadow-md">
            <span class="text-4xl text-green-500 material-symbols-outlined">
                check_circle
            </span>
            Login URL is sent to your email.
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3cc710b2fb1cfcc6cba554e9525ade40)): ?>
<?php $attributes = $__attributesOriginal3cc710b2fb1cfcc6cba554e9525ade40; ?>
<?php unset($__attributesOriginal3cc710b2fb1cfcc6cba554e9525ade40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3cc710b2fb1cfcc6cba554e9525ade40)): ?>
<?php $component = $__componentOriginal3cc710b2fb1cfcc6cba554e9525ade40; ?>
<?php unset($__componentOriginal3cc710b2fb1cfcc6cba554e9525ade40); ?>
<?php endif; ?><?php /**PATH /home/devd/WorkProjects/Php/kadavil_thrikkovil_webapp/resources/views/admin/loginsuccess.blade.php ENDPATH**/ ?>