<?php if (isset($component)) { $__componentOriginal3cc710b2fb1cfcc6cba554e9525ade40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3cc710b2fb1cfcc6cba554e9525ade40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.base-app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> 
    <main class="grid w-full h-full lg:flex ">
        <section class="w-full h-full border-2 shadow-md lg:w-1/6">
            <div class="flex flex-col h-full justify-items-start">
                <div class="hidden w-full p-10 text-xl font-semibold border-b-2 lg:block">
                    Logged in as 
                    <span class="text-3xl capitalize">
                        <?php echo e($user->name); ?>

                    </span>
                </div>
                
                <ul style="grid-template-rows: min-content min-content 1fr;" class="flex flex-auto gap-2 lg:gap-0 justify-items-end lg:grid">
                    <a class="lg:w-full" href="/admin/console/today">
                        <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(["flex items-center w-full gap-3 p-5 font-semibold border-b-2", "bg-p1 bg-opacity-60" => request()->routeIs('console.today')]); ?>">
                            <span class="material-symbols-outlined">
                                today
                            </span>
                            Today
                        </li>
                    </a>
                    <a class="lg:w-full" href="/admin/console/recent">
                        <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(["flex items-center w-full gap-3 p-5 font-semibold border-b-2", "bg-p1 bg-opacity-60" => request()->routeIs('console.recent')]); ?>">
                            <span class="material-symbols-outlined">
                                history
                            </span>
                            Recent
                        </li>
                    </a>
                    <a class="lg:w-full" class="flex-auto" href="/admin/logout">
                        
                    </a>
                </ul>
            </div>
        </section>
        <section class="w-full">
            <?php echo e($slot); ?>

        </section>
    </main>    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3cc710b2fb1cfcc6cba554e9525ade40)): ?>
<?php $attributes = $__attributesOriginal3cc710b2fb1cfcc6cba554e9525ade40; ?>
<?php unset($__attributesOriginal3cc710b2fb1cfcc6cba554e9525ade40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3cc710b2fb1cfcc6cba554e9525ade40)): ?>
<?php $component = $__componentOriginal3cc710b2fb1cfcc6cba554e9525ade40; ?>
<?php unset($__componentOriginal3cc710b2fb1cfcc6cba554e9525ade40); ?>
<?php endif; ?><?php /**PATH /home/devd/WorkProjects/Php/kadavil_thrikkovil_webapp/resources/views/components/admin-menu.blade.php ENDPATH**/ ?>