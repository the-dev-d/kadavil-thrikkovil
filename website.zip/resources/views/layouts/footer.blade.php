<footer class="grid px-6 py-20 lg:px-32 lg:grid-cols-3 bg-c2 bg-amber-950">
    <div class="pages">
        <h3 class="text-2xl font-bold text-white">Pages</h3>
        <ul class="grid gap-3 mt-5 text-white">
            <li class="text-xl">ഹോം പേജ്</li>
            <li class="text-xl">ക്ഷേത്രത്തെക്കുറിച്ച്</li>
            <a href="/vazhipaad">
            <li class="text-xl">വഴിപാടുകൾ</li>
            </a>
            <li class="text-xl">തിരുമേനിയെകുറിച്ച്</li>
            <li class="text-xl">സ്ഥലം</li>
            <li class="text-xl">ബന്ധപ്പെടുക</li>
        </ul>
    </div>
</footer>