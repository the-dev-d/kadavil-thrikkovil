<x-base-app> 

    <div class="container grid w-screen h-screen mx-auto place-items-center">

        <div class="flex items-center justify-center gap-3 p-16 text-2xl border-2 rounded-md shadow-md">
            <span class="text-4xl text-green-500 material-symbols-outlined">
                check_circle
            </span>
            Login URL is sent to your email.
        </div>
    </div>

</x-base-app>